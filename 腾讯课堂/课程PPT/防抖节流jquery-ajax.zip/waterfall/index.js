var oLi = document.getElementsByTagName('li'),
    imgWidth = 200,
    page = 1,
    flag = true;

function getData() {
    if(flag) {
        flag = false;
        // ajax('get', 'getPics.php', addItem, 'cpage=' + page, true);
        $.ajax({
            type: 'GET',
            url: 'https://api.douban.com/v2/music/search',
            data: 'q=aa',
            dataType: 'jsonp',
            context: document.body,
            crossDomain: false,
            success: function(data) {
                console.log(this)
                console.log(1);
            },
            error: function (data) {
                console.log(data);
            }
        })
        page++;
    }
}
getData(page);
function dg(data) {
    console.log(2)
}

// ajax回掉函数 添加图片
function addItem(data) {
    var value = JSON.parse(data);
    console.log(value);
    if(value.length > 0) {
        value.forEach(function (ele, index) {
            var index = minListIndex(oLi);
            var oItem = document.createElement('div'),
                oP = document.createElement('p'),
                oImg = new Image();
            
            oItem.className = 'item';
            oImg.style.height = ele.width/ele.height * imgWidth + 'px';
            
            oImg.src = ele.preview;
            oP.innerHTML = ele.title;

            oItem.appendChild(oImg);
            oItem.appendChild(oP);
            oLi[index].appendChild(oItem);

            oImg.onerror = function () {
                oImg.style.margin = '-1px';
            }
        })
    }
    flag = true;
}

// 获取最小列的索引
function minListIndex(dom) {
    var index = 0,
        len = dom.length,
        minListLength = dom[index].offsetHeight;
    for(var i = 1; i < len; i++) {
        if(minListLength > dom[i].offsetHeight) {
            minListLength = dom[i].offsetHeight;
            index = i;
        }
    }
    return index;
}

window.onscroll = throttle(show, 500);
function throttle(func, wait) {
    var timer = null;
    return function () {
        var _this = this;
        var argus = arguments;
        if(!timer) {
            timer = setTimeout(function () {
                func.apply(_this, argus);
                timer = null;
            }, wait);
        } 
    }
}
function show() {
    var minHeight = oLi[minListIndex(oLi)].offsetHeight,
        scrollHeight = document.documentElement.scrollTop || document.body.scrollTop;
        clientHeight = document.documentElement.clientHeight || document.body.clientHeight;

    if( scrollHeight + clientHeight >= minHeight) {
        getData(page);
    }   

}